CSCI3260 Assignment 1 Keyboard / Mouse Events  

 - Name: Chu Kai Chun   
 - Student ID: 1155093260

Manipulation:

	You are the boxman, feel free to explore this world! Lets see if you can block the sun with something!

        // Key "Esc": exit
        // Key "Q" or "E" : rotate the boxman
	// Key "W" , "A", "S", "D" : move forward, leftward, backward, and rightward
        // Key "H" or "J": rotate the view to left or right
	// Key "Up" , "Down" , "Left" , "Right": move the cloud
	// Key "N" or "M" : To enlarge or dwindle the cloud
	// Mouse "Scroll": Zoom in/ Zoom out
	
	

